
public abstract class Product {
	
	protected String hostName;
	protected String location;
	protected int startTime;
	protected int endTime;
	protected int guests;
	public String getHostName() {
		return hostName;
	}
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public int getStartTime() {
		return startTime;
	}
	public void setStartTime(int startTime) {
		this.startTime = startTime;
	}
	public int getEndTime() {
		return endTime;
	}
	public void setEndTime(int endTime) {
		this.endTime = endTime;
	}
	public int getGuests() {
		return guests;
	}
	public void setGuests(int guests) {
		this.guests = guests;
	}
	public Product(String hostName, String location, int startTime, int endTime, int guests) {
		super();
		this.hostName = hostName;
		this.location = location;
		this.startTime = startTime;
		this.endTime = endTime;
		this.guests = guests;
	}

	
	
	
	
}
