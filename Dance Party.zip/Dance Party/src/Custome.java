
public class Custome extends Product {

	protected String theme;

	public String getTheme() {
		return theme;
	}

	public void setTheme(String theme) {
		this.theme = theme;
	}

	public Custome(String hostName, String location, int startTime, int endTime, int guests, String theme) {
		super(hostName, location, startTime, endTime, guests);
		this.theme = theme;
	}

	public int getTotalCost() {
		return 3 * this.guests * (this.endTime - this.startTime);
	}

	

	

	
	

}
