
public class Dance extends Product {
	protected String dressCode;

	public String getDressCode() {
		return dressCode;
	}

	public void setDressCode(String dressCode) {
		this.dressCode = dressCode;
	}

	public Dance(String hostName, String location, int startTime, int endTime, int guests, String dressCode) {
		super(hostName, location, startTime, endTime, guests);
		this.dressCode = dressCode;
	}
	

	public int getTotalCost() {
		return 2 * this.guests * (this.endTime - this.startTime);
	}
	
	
	
}
