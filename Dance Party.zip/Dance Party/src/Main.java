import java.util.Scanner;
import java.util.Vector;

public class Main {

	public Main() {
		Scanner scan = new Scanner(System.in);
		Vector<Product> products = new Vector<>();
		int choise = -1;
		while(true) {
			System.out.println("1. Organize Party");
			System.out.println("2. View Party");
			System.out.println("3. Exit");
			choise = scan.nextInt();
			
			if (choise == 1) {
				//Organize Party
				String partyType = "";
				String hostName = "";
				String location = "";
				int startTime = 0;
				int endTime = 0;
				int guest = 0;
				
				do {
					System.out.println("Party Type: ");
					partyType = scan.nextLine();
				} while (!partyType.equals("Dance") && !partyType.equals("Custome"));
				
				do {
					System.out.println("Host Name: ");
					hostName = scan.nextLine();
				} while (hostName.length() < 4);
				
				do {
					System.out.println("Location: ");
					location = scan.nextLine();
				} while (!location.contains(" "));
				
				do {
					System.out.println("Start Time: ");
					startTime = scan.nextInt();
					scan.nextLine();
				} while (startTime < 6 || startTime > 18);
				
				do {
					System.out.println("End Time : ");
					endTime = scan.nextInt();
					scan.nextLine();
				} while ((endTime < 12 || endTime > 24 ) || endTime < startTime);
				
				do {
					System.out.println("Guest: ");
					guest = scan.nextInt();
					scan.nextLine();
				} while (guest<1);
				
				Product product = null;
				if (partyType.equals("Custome")) {
					String theme = "";
					do {
						System.out.println("Theme: ");
						theme = scan.nextLine();
					} while (!theme.equals("Halloween") && !theme.equals("80s") && !theme.equals("Film"));
					
					product = new Custome(hostName, location, startTime, endTime, guest, theme);
				}
				else {
					String dressCode = "";
					do {
						System.out.println("Dress Code: ");
						dressCode = scan.nextLine();
					} while (!dressCode.equals("Informal") && !dressCode.equals("Formal") && !dressCode.equals("Casual"));
					product = new Dance(hostName, location, startTime, endTime, guest, dressCode);
				}
				products.add(product);
			}
			
			if (choise == 2) {
				//VIEW
				for (Product product : products) {
					System.out.printf("Host Name: %s\n", product.getHostName());
					System.out.printf("Location: %s\n", product.getLocation());
					System.out.printf("Time: %d:00-%d:00\n", product.getStartTime(), product.getEndTime());
					System.out.printf("Total Guests: %d\n", product.getGuests());
					
					if (product instanceof Custome) {
						Custome custome = (Custome) product;
						System.out.printf("Theme: %s\n", custome.getTheme());
						System.out.printf("Total Cost: %d\n", custome.getTotalCost());
					}
					if (product instanceof Dance) {
						Dance dance = (Dance) product;
						System.out.printf("Dress Code: %s\n", dance.getDressCode());
						System.out.printf("Total Cost: %d\n", dance.getTotalCost());
					}
				}
			}
			
			if (choise == 3) {
				break;
			}
		}
	}
	public static void main(String[] args) {
		new Main();
	}
	

}
